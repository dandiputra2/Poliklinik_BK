<?php
$databaseHost = 'localhost';
$databaseName = 'poliklinik';
$databaseUsername = 'poliklinik';
$databasePassword = ''; 

$mysqli = mysqli_connect($databaseHost,$databaseUsername,$databasePassword, $databaseName);

// Periksa koneksi
if (!$mysqli) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
echo "Koneksi berhasil!";
?>
