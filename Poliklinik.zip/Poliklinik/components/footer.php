<footer class="bg-blue-900 text-black py-6 w-full opacity-100">

    <div class="max-w-7xl mx-auto px-4 text-center">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
            <div>
                <strong>&copy; 2024/2025 
                    <a href="https://wa.link/2lflpo" class="text-yellow-400 hover:underline">A11.2021.13684_Dandi Mahendra Putra Firdaus</a>.
                    All rights reserved.
                </strong>
            </div>
        </div>
    </div>
</footer>
